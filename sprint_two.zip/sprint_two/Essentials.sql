CREATE DATABASE IF NOT EXISTS Essentials;
USE Essentials;
CREATE TABLE Users (userID INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(70) UNIQUE NOT NULL, email VARCHAR(100) UNIQUE NOT NULL, acc_password VARCHAR(100) NOT NULL, phoneNo VARCHAR(15), userType ENUM('admin', 'customer', 'staff') NOT NULL DEFAULT 'customer');
CREATE TABLE Products (productID INT AUTO_INCREMENT PRIMARY KEY, productName VARCHAR(150) NOT NULL, info TEXT, price DECIMAL(10,2) NOT NULL, category VARCHAR(150) NOT NULL, availability BOOLEAN DEFAULT TRUE, image_url VARCHAR(300));
CREATE TABLE Orders (orderID INT AUTO_INCREMENT PRIMARY KEY, userID INT NOT NULL, orderStatus ENUM('pending', 'ready', 'confirmed', 'completed', 'canceled') DEFAULT 'pending', orderType ENUM('delivery', 'pickup') NOT NULL, totalExpense DECIMAL(10,2) NOT NULL, deliveryAddress TEXT, FOREIGN KEY(userID) REFERENCES Users(userID));
CREATE TABLE orderItems(orderItemID INT AUTO_INCREMENT PRIMARY KEY, orderID INT NOT NULL, productID INT NOT NULL, quantity INT NOT NULL CHECK(quantity > 0), unitPrice DECIMAL(10,2) NOT NULL, FOREIGN KEY(orderID) REFERENCES Orders(orderID), FOREIGN KEY(productID) REFERENCES Products(productID));
CREATE TABLE Payments (paymentID INT AUTO_INCREMENT PRIMARY KEY, orderID INT NOT NULL, paymentMethod ENUM('cash', 'AshesiMealPlan', 'MobileMoney') NOT NULL, paymentStatus ENUM('pending', 'failed', 'confirmed', 'refunded') DEFAULT 'pending', amount DECIMAL(10,2) NOT NULL, transactionID VARCHAR(150), FOREIGN KEY(orderID) REFERENCES Orders(orderID));
CREATE TABLE storeInventory (inventoryID INT AUTO_INCREMENT PRIMARY KEY, productID INT NOT NULL UNIQUE, stockQuantity INT NOT NULL CHECK(stockQuantity >= 0), lowStockThreshold INT DEFAULT 10, FOREIGN KEY(productID) REFERENCES Products(productID));

INSERT INTO Products(productName, info, price, category, image_url) VALUES
('frytol cooking oil', '100% pure vegeatable oil fortified with vitamin A', 20, 'Food', "C:\Users\josep\Downloads\web technologies\sprint one\cooking oil.jpg"),
('wheat drink', 'Flavored milk drink', 17, 'Beverages', "C:\Users\josep\Downloads\web technologies\sprint one\wheat drink.jpg"),
('voltic mineral water', 'pure, zero calorie, zero additive, hydrating, and supports healthy digestion and skin', 3, 'Beverages', "C:\Users\josep\Downloads\web technologies\sprint one\water.jpg"),
('fluffy toilet roll', 'affordable, utrasoft and absorbent', 5, 'Toiletries', "C:\Users\josep\Downloads\web technologies\sprint one\t-roll.jpg"),
('famous amos cookies', 'Made with premiun ambrosia chocolate chips', 13, 'Snacks', "C:\Users\josep\Downloads\web technologies\sprint one\cookies.jpg"),
('Niche chocolate', 'Flavorful and rich in milk', 20, 'Snacks', "C:\Users\josep\Downloads\web technologies\sprint one\choco.jpeg"),
('Buldak', 'Hot chicken flavor', 25, 'Groceries', "C:\Users\josep\Downloads\web technologies\sprint one\buldak.jpg");

INSERT INTO storeInventory (product_id, stock_quantity, low_stock_threshold) VALUES
(1, 50, 10),
(2, 30, 5),
(3, 100, 20),
(4, 25, 5),
(5, 75, 15),
(6, 15, 3),
(7, 40, 8);
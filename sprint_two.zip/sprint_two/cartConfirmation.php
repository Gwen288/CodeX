<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Order Confirmation...Essentials</title>
    <meta charset = "UTF-8">
    <meta name="viewport" content="width=device-width, initials-scale=1.0">
    <link rel="stylesheet" href="checkout.css">
</head>
<body>
    <header class="header">
        <nav class="navbar container">
            <ul class="nav-links">
                <li><a href="homepage.html">Home</a></li>
                <li><a href="login.html">Login</a></li>
            </ul>
        </nav>
    </header>

    <main class="header">
        <div class="checkout-process">
            <div class="process">
                <div class="process-number">1</div>
                <div class="process-text">cart</div>
            </div>

            <div class="process-active">
                <div class="process-number">2</div>
                <div class="process-text">checkout</div>
            </div>

            <div class="process-active">
                <div class="process-number">3</div>
                <div class="process-text">confirmation</div>
            </div>
        </div>

        <div class="checkout-grid">
            <div class="checkout-left">
                <form id="checkout-form">
                    <div class="checkout-section">
                        <h2 class="section-title">Shipping Info</h2>

                        <div class="form-group">
                            <label for="fullName">Full name</label>
                            <input type="text" id="fullName" required>
                        </div>

                        <div class="form-group">
                            <label for="phone">Phone No</label>
                            <input type="tel" id="phone" required>
                        </div>

                        <div class="form-group">
                            <label for="Address">Hostel Address</label>
                            <input type="text" id="Address" required>
                        </div>

                        <div class="form-group">
                            <label for="deliveryOption">Delivery Option</label>
                            <select id="deliveryOption" name="deliveryOption" required>
                                <option value="">Select a delivery option</option>
                                <option value="pickup">Pickup</option>
                                <option value="delivery">Campus Hosel Delivery</option>
                            </select>
                        </div>
                    </div>

                    <div class="checkout-section">
                        <h2 class="section-title">Payment method</h2>
                        <div class="payment-method-selection" onclick="selectPaymeny(this)">
                            <input type="radio" id="mobileMoney" name="payment-method" value="mobileMoney">
                            <div>
                                <div>Mobile Money</div>
                                <div>Mtn, AirtelTigo, Telecel</div>
                            </div>
                        </div>

                        <div class="payment-method-selection" onclick="selectPaymeny(this)">
                            <input type="radio" id="mealPlan" name="payment-method" value="mealPlan">
                            <div>
                                <div>Ashesi Meal Plan</div>
                            </div>
                        </div>

                        <div class="payment-method-selection" onclick="selectPaymeny(this)">
                            <input type="radio" id="cash" name="payment-method" value="cash">
                            <div>
                                <div>Pay on Pickup</div>
                                <div>Pay when delivery is made</div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>

            <div class="checkout-right">
                <div class="checkout-section">
                    <h2 class="section-title">Order Overview</h2>

                    <div id="checkout-items">
            
                    </div>

                    <div class="cart-summary">
                        <span>Subtotal:</span>
                        <span id="checkout-subtotal">GHS 45.99</span>
                    </div>

                    <div class="summary">
                        <span>Delivery Fee:</span>
                        <span>GHS 2.00</span>
                    </div>

                    <div class="summary">
                        <span>Total:</span>
                        <span id="checkout-total">GHS 47.99</span>
                    </div>

                </div>

                <button type="button" class="btn btn-block" onclick="placeOrder()">Place Order</button>
                <a href="checkoutCart.html" class="btn btn-block btn-outline" style="margin-top: 1rem;" >Go back to cart</a>
            </div>
        </div>
    </main>

    <script>
        window.onload = function() {
            showCartItems();
        };

        function showCartItems() {
            let cartContainer = document.getElementById('cart-itemsCont');
            let totalElement = document.getElementById('cart-total');
            let checkoutButton = document.getElementById('proceed-checkout');

            cartContainer.innerHTML = '';
            let itemNo = localStorage.getItem(çart-itemNo);

            if(!itemNo || itemNo === '0') {
                cartContainer.innerHTML = '<p class="text-center">Cart is empty</p>';
                totalElement.textContent = 'GHS 0.00';
                checkoutButton.style.display = 'none';
                return;
            }
            checkoutButton.style.display = 'block';

            let totalPrice = 0;
            let itemCount = parseInt(itemNo);

            for(let i = 0; i < itenCount; i++) {
                let name = localStorage.getItem('cart-item_' + i + '_name');
                let price = localStorage.getItem('cart-item_' + i + '_price');
                let quantity = localStorage.getItem('cart-item_' + i + '_quantity');

                if(name &&price && quantity) {
                    let itemPrice = parseFloat(price);
                    let itemQuantity = parseInt(quantity);
                    let itemTotal = itemPrice * itemQuantity;
                    totalPrice = totalPrice + itemtotal;

                    let itemHTML = `
                        <div class="cart-item">
                            <div class="cart-item-image">
                                <img src="C:\Users\josep\Downloads\web technologies\sprint one\choco.jpeg" alt="choco" style="width: 100%; height: 100%; object-fit: cover; border-radius: 5px;">
                            </div>
                            
                            <div class="cart-item-details">
                                <div class="cartItem-name">Niche chocolate</div>
                                <div class="cartItem-price">GHS 12.99</div>
                                <div class="cartItem-quantity">
                                    <button class="quantity-btn" onclick="changeQuantity(1, -1)">-</button>
                                    <input type="text" class="quantity-input" value="1" readonly>
                                    <button class="quantity-btn" onclick="changeQuantity(1, 1)">+</button>
                                </div>
                            </div>

                            <button class="quantity-btn" onclick="removeItem(1)">remove</button>

                            <div class="cart-item-image">
                                <img src="C:\Users\josep\Downloads\web technologies\sprint one\water.jpg" alt="water" style="width: 100%; height: 100%; object-fit: cover; border-radius: 5px;">
                            </div>
                            
                            <div class="cart-item-details">
                                <div class="cartItem-name">Voltic water</div>
                                <div class="cartItem-price">GHS 3.00</div>
                                <div class="cartItem-quantity">
                                    <button class="quantity-btn" onclick="changeQuantity(5, -1)">-</button>
                                    <input type="text" class="quantity-input" value="5" readonly>
                                    <button class="quantity-btn" onclick="changeQuantity(5, 1)">+</button>
                                </div>
                            </div>

                            <button class="quantity-btn" onclick="removeItem(5)">remove</button>

                            <div class="cart-item-image">
                                <img src="C:\Users\josep\Downloads\web technologies\sprint one\cookies.jpg" alt="cookies" style="width: 100%; height: 100%; object-fit: cover; border-radius: 5px;">
                            </div>
                            
                            <div class="cart-item-details">
                                <div class="cartItem-name">Famous Amos Cookies</div>
                                <div class="cartItem-price">GHS 13.00</div>
                                <div class="cartItem-quantity">
                                    <button class="quantity-btn" onclick="changeQuantity(1, -1)">-</button>
                                    <input type="text" class="quantity-input" value="1" readonly>
                                    <button class="quantity-btn" onclick="changeQuantity(1, 1)">+</button>
                                </div>
                            </div>

                            <button class="quantity-btn" onclick="removeItem(1)">remove</button>

                            <div class="cart-item-image">
                                <img src="C:\Users\josep\Downloads\web technologies\sprint one\t-roll.jpg" alt="t-roll" style="width: 100%; height: 100%; object-fit: cover; border-radius: 5px;">
                            </div>
                            
                            <div class="cart-item-details">
                                <div class="cartItem-name">Fluffy Toilet Roll</div>
                                <div class="cartItem-price">GHS 5.00</div>
                                <div class="cartItem-quantity">
                                    <button class="quantity-btn" onclick="changeQuantity(1, -1)">-</button>
                                    <input type="text" class="quantity-input" value="1" readonly>
                                    <button class="quantity-btn" onclick="changeQuantity(1, 1)">+</button>
                                </div>
                            </div>

                            <button class="quantity-btn" onclick="removeItem(1)">remove</button>
                        </div>
                    `;

                    cartContainer.innerHTML += itemHTML;

                }
            }

            totalElement.textContent = 'GHS 45.99';
        }

        function selectPaymentMethod(element) {
            document.querySelectorAll('.payment-method').forEach(p => p.classList.remove('selected'));
            element.classList.add('selected');
            element.querySelector('input').checked = true;
        }

        function placeOrder() {
            let fields =['fullName', 'email', 'phone', 'Address', 'deliveryOption'];

            for(let field of fields) {
                if(!document.getElementById(field).value) {
                    alert("All fields must be filled");
                    return;
                }
            }

            localStorage.setItem('orderTotal', document.getElementById('checkout-total').textContent);
            localStorage.setItem('paymentMethod', document.querySelector('input[name="payment-method"]:checked').value);
            localStorage.setItem('deliveryOption', document.getElementById('deliveryOption').value);

            window.location.href = 'Checkout.html'
        }
    </script>
</body>
</html>

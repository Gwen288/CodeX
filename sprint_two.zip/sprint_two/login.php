<! doctype html>
<html lang="UTF-8">
    <head >
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width , initial-scale= 1.0">
        <title>Login</title>
        <link rel="stylesheet" href="registration.css">
    </head>
    <body>
        <div class="mainCard">

        <?php
        require_once 'confi.php';
        if($_SERVER["REQUEST_METHOD"] == "POST") {
            $database = new Database();
            $conn  = $database->getconnection();
            $email = $_POST["email"];
            $password = $_POST["password"];
            $query = "SELECT userID, username, email, acc_password, userType FROM Users WHERE email = :email";
            $stmt = $conn->prepare($query);
            $stmt->bind_param(':email', $email);
            $stmt->execute();
            if($stmt->rowCount() == 1) {
                $user = $stmt->fetch(PDO::FETCH_ASSOC);
                if(password_verify($password, $user['acc_password'])) {
                    session_start();
                    $_SESSION['user_id'] = $user['userID'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['user_type'] = $user['userType'];
                    header("Location: homepage.html");
                    exit();
                }
                else {
                    echo "Invalid password";
                }
            }
            else {
                echo "Use not found";
            }
        }
        ?>
     
            

         <form class="card">
            <h2>Login</h2> 
            
                <input type="text" placeholder="email" class="input" required></input>

                <input type='password' placeholder="password" class="input" required></input>

                <div class="Check"> 
                    <input type="checkbox" id="email" value="Remember me" >
                    <label for="email" id="check" >Remember me</label>
                </div>
    
            <button type="submit">Login</button>
         <form>
            <p id="paragraph">Don't have an account?<a href="SignUp.html">Signup</a></p>
         </div>
    </body>
</html>

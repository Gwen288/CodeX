<?php
require_once 'confi.php';

function initializeDatabase() {
    $database = new Database();

    try {
        $sql = file_get_contents('database/setup_database.sql');
        $database->getConnection()->exec($sql);
        $sample = file_get_contents('database/setup_database.sql');
        $database->getConnection()->exec($sample);  
        echo "Database successfully initialized";
        return true;
    }
    catch(PDOException $exception) {
        echo "Error initializing database: " . $exception->getMessage();
        return false;   
    }
}
if(basename(__FILE__) == basename($_SERVER["SCRIPT_FILENAME"])) {
    initializeDatabase();
}
?>
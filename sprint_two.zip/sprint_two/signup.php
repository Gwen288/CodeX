<! doctype html>
<html lang="UTF-8">
    <head >
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width , initial-scale= 1.0">
        <title>Login</title>
        <link rel="stylesheet" href="registration.css">
    </head>
    <body>
        <div class="mainCard">

        <?php
        require_once 'confi.php';
        if($_SERVER["REQUEST_METHOD"] == "POST") {
            $database = new Database();
            $conn  = $database->getconnection();
            $username = $_POST["username"];
            $email = $_POST["email"];
            $password = password_hash($_POST["password"], PASSWORD_DEFAULT);
            $phone = $_POST["phone"] ?? NULL;
            $query = "INSERT INTO Users (username, email, acc_password, phoneNo) VALUES (:username, :email, :password, :phone)";
            $stmt = $conn->prepare($query);
            $stmt->bind_param(':username', $username);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':password', $password);
            $stmt->bindParam(':phone', $phone);
            if($stmt->execute()) {
                header("Location: login.html");
                exit();
            }
            else {
                echo "Error creating account";
            }
        }
        ?>

            
            

         <form method="POST" class="card">
            <h2>SignUp</h2> 
                <input type="text" name="username" placeholder="username" class="input" required></input>
                <input type="text" placeholder="email" class="input" required></input>
                <input type="password" placeholder="create password" class="input" required></input>
                <input type='password' placeholder="confirm password" class="input" required></input>
<!--
                <div class="Check"> 
                    <input type="checkbox" id="email" value="Remember me" >
                    <label for="email" id="check" >Remember me</label>
                </div>
            -->
            <button type="submit">Login</button>
         <form>
            <p id="paragraph">Already have an account?<a href="login.html">Login</a></p>
         </div>
    </body>
</html>
<?php

<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Order Confirmation...Essentials</title>
    <meta charset = "UTF-8">
    <meta name="viewport" content="width=device-width, initials-scale=1.0">
    <link rel="stylesheet" href="checkout.css">
</head>
<body>
    <header class="header">
        <nav class="navbar container">
            <ul class="nav-links">
                <li><a href="homepage.html">Home</a></li>
                <li><a href="login.html">Account</a></li>
            </ul>
        </nav>
    </header>

    <main class="header">
        <div class="checkout-process">
            <div class="process">
                <div class="process-number">1</div>
                <div class="process-text">cart</div>
            </div>

            <div class="process-active">
                <div class="process-number">2</div>
                <div class="process-text">checkout</div>
            </div>

            <div class="process-active">
                <div class="process-number">3</div>
                <div class="process-text">confirmation</div>
            </div>
        </div>

        <h1>Shopping Cart</h1>

        <div class="cart-items" id="cart-itemsCont">
        </div>

        <div class="cart-sumamry">
            <div class="summary">
                <strong>Total:</strong>
                <span id="cart-total">GHS 45.99</span>
            </div>

            <div class="summary">
                <strong>delivery Fee:</strong>
                <span>GHS 2.00</span>
            </div>

            <a href="cartConfirmation.html" class="btn btn-block" style="margin-top: 1rem;" id="proceed-checkout">Proceed to checkout</a>
            <a href="products.html" class="btn btn-block btn-outline" style="margin-top: 1rem;" id="proceed-checkout">Continue shopping</a>
        </div>
    </main>

    <script>
        window.onload = function() {
            showCartItems();
        };

        function showCartItems() {
            let cartContainer = document.getElementById('cart-itemsCont');
            let totalElement = document.getElementById('cart-total');
            let checkoutButton = document.getElementById('proceed-checkout');

            cartContainer.innerHTML = '';

            let itemNo = localStorage.getItem(çart-itemNo);

            if(!itemNo || itemNo === '0') {
                cartContainer.innerHTML = '<p class="text-center">Cart is empty</p>';
                totalElement.textContent = 'GHS 0.00';
                checkoutButton.style.display = 'none';
                return;
            }
            checkoutButton.style.display = 'block';

            let totalPrice = 0;
            let itemCount = parseInt(itemNo);

            for(let i = 0; i < itenCount; i++) {
                let name = localStorage.getItem('cart-item_' + i + '_name');
                let price = localStorage.getItem('cart-item_' + i + '_price');
                let quantity = localStorage.getItem('cart-item_' + i + '_quantity');

                if(name &&price && quantity) {
                    let itemPrice = parseFloat(price);
                    let itemQuantity = parseInt(quantity);
                    let itemTotal = itemPrice * itemQuantity;
                    totalPrice = totalPrice + itemtotal;

                    let itemHTML = `
                        <div class="cart-item">
                            <div class="cart-item-image">
                                <img src="C:\Users\josep\Downloads\web technologies\sprint one\choco.jpeg" alt="choco" style="width: 100%; height: 100%; object-fit: cover; border-radius: 5px;">
                            </div>
                            
                            <div class="cart-item-details">
                                <div class="cartItem-name">Niche chocolate</div>
                                <div class="cartItem-price">GHS 12.99</div>
                                <div class="cartItem-quantity">
                                    <button class="quantity-btn" onclick="changeQuantity(1, -1)">-</button>
                                    <input type="text" class="quantity-input" value="1" readonly>
                                    <button class="quantity-btn" onclick="changeQuantity(1, 1)">+</button>
                                </div>
                            </div>

                            <button class="quantity-btn" onclick="removeItem(1)">remove</button>

                            <div class="cart-item-image">
                                <img src="C:\Users\josep\Downloads\web technologies\sprint one\water.jpg" alt="water" style="width: 100%; height: 100%; object-fit: cover; border-radius: 5px;">
                            </div>
                            
                            <div class="cart-item-details">
                                <div class="cartItem-name">Voltic water</div>
                                <div class="cartItem-price">GHS 3.00</div>
                                <div class="cartItem-quantity">
                                    <button class="quantity-btn" onclick="changeQuantity(5, -1)">-</button>
                                    <input type="text" class="quantity-input" value="5" readonly>
                                    <button class="quantity-btn" onclick="changeQuantity(5, 1)">+</button>
                                </div>
                            </div>

                            <button class="quantity-btn" onclick="removeItem(5)">remove</button>

                            <div class="cart-item-image">
                                <img src="C:\Users\josep\Downloads\web technologies\sprint one\cookies.jpg" alt="cookies" style="width: 100%; height: 100%; object-fit: cover; border-radius: 5px;">
                            </div>
                            
                            <div class="cart-item-details">
                                <div class="cartItem-name">Famous Amos Cookies</div>
                                <div class="cartItem-price">GHS 13.00</div>
                                <div class="cartItem-quantity">
                                    <button class="quantity-btn" onclick="changeQuantity(1, -1)">-</button>
                                    <input type="text" class="quantity-input" value="1" readonly>
                                    <button class="quantity-btn" onclick="changeQuantity(1, 1)">+</button>
                                </div>
                            </div>

                            <button class="quantity-btn" onclick="removeItem(1)">remove</button>

                            <div class="cart-item-image">
                                <img src="C:\Users\josep\Downloads\web technologies\sprint one\t-roll.jpg" alt="t-roll" style="width: 100%; height: 100%; object-fit: cover; border-radius: 5px;">
                            </div>
                            
                            <div class="cart-item-details">
                                <div class="cartItem-name">Fluffy Toilet Roll</div>
                                <div class="cartItem-price">GHS 5.00</div>
                                <div class="cartItem-quantity">
                                    <button class="quantity-btn" onclick="changeQuantity(1, -1)">-</button>
                                    <input type="text" class="quantity-input" value="1" readonly>
                                    <button class="quantity-btn" onclick="changeQuantity(1, 1)">+</button>
                                </div>
                            </div>

                            <button class="quantity-btn" onclick="removeItem(1)">remove</button>
                        </div>
                    `;

                    cartContainer.innerHTML += itemHTML;

                }
            }

            totalElement.textContent = 'GHS 45.99';
        }

        function changeQuantity(index, change) {
            let quantity = localStorage.getItem('cart-item' + index + '_quantity');

            if(quantity) {
                let newQuantity = parseInt(quantity) + change;

                if(newQuantity <= 0) {
                    removeItem(index) ;            
                }

                else {
                    localStorage.setItem('cart-item' + index + '_quantity', newQuantity.toString());
                    showCartItems;
                }
            }
        }

        function removeItem(index) {
            localStorage.getItem('cart-item' + index + '_name');
            localStorage.getItem('cart-item' + index + '_price');
            localStorage.removeItem('cart-item' + index + '_quantity');

            let itemNo = localStorage.getItem('cart-itemNo');
            if(itemNo) {
                let newNo = parseInt(itemNo) - 1;
                localStorage.setItem('cart-itemNo', newNo.toString());
            }

            showCartItems();
        }
    </script>
</body>
</html>
<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Order Confirmation...Essentials</title>
    <meta charset = "UTF-8">
    <meta name="viewport" content="width=device-width, initials-scale=1.0">
    <link rel="stylesheet" href="checkout.css">
</head>
<body>
    <header class="header">
        <nav class="navbar container">
            <ul class="nav-links">
                <li><a href="homepage.html">Home</a></li>
                <li><a href="login.html">Account</a></li>
            </ul>
        </nav>
    </header>

    <main class="header">
        <div class="checkout-process">
            <div class="process">
                <div class="process-number">1</div>
                <div class="process-text">cart</div>
            </div>

            <div class="process-active">
                <div class="process-number">2</div>
                <div class="process-text">checkout</div>
            </div>

            <div class="process-active">
                <div class="process-number">3</div>
                <div class="process-text">confirmation</div>
            </div>
        </div>

        <div class="confirmation-card">
            <h1 class="confirmation-title">Order Confirmed</h1>
            <p>The confirmation details have been sent to your email</p>
            <p>Show the confirmation order details to the delivery man or cashier as prove of order and/or payment</p>

            <div class="confirmation-details">
                <div class="detail-row">
                    <strong>Order No</strong>
                    <span>#ADE-098-235</span>
                </div>

                <div class="detail-row">
                    <strong>Order Date</strong>
                    <span id="order-date">7 November 2025</span>
                </div>

                <div class="detail-row">
                    <strong>Delivery date</strong>
                    <span id="delivery-date">7 November 2025</span>
                </div>

                <div class="detail-row">
                    <strong>Estimated Ready Time</strong>
                    <span>10 minutes</span>
                </div>

                <div class="detail-row">
                    <strong>Total expense</strong>
                    <span id="confirmed-total">GHS 47.99</span>
                </div>

                <div class="detail-row">
                    <strong>Payment Method</strong>
                    <span id="payment-method">Ashesi Meal Plan</span>
                </div>

                <div class="detail-row">
                    <strong>Delivery option</strong>
                    <span id="delivery-option">Pickup</span>
                </div>

                <div class="afterOrder">
                    <a href="products.html" class="btn">Continue shopping</a>
                    <a href="" class="btn btn-outline">Print receipt</a>
            </div>
        </div>
    </main>

    <script>
        window.onload = function() {
            let orderTotal = localStorage.getItem('orderTotal');
            let paymentMethod = localStorage.getItem('paymentMethod');
            let deliveryOption = localStorage.getItem('deliveryOption');

            if(orderTotal) {
                document.getElementById('confirmation-total').textContent = orderTotal;
            }

            if(paymentMethod) {
                document.getElementById('payment-method').textContent = paymentMethod;
            }

            if(deliveryOption) {
                document.getElementById('delivery-option').textContent = deliveryOption;
            }

            let today = new Date();
            let day = today.getDate();
            let month = today.getMonth() + 1;
            let year = today.getYear();

            let monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
            let dateS = day + " " + monthsName[month-1] + " " + year;

            document.getElementById('order-date').textContent = dateS;
            document.getElementById('delivery-date').textContent = dateS;

            localStrorage.removeItem('cart');
            localStrorage.removeItem('orderTotal');
            localStrorage.removeItem('paymentmethod');
            localStrorage.removeItem('deliveryOption');
        };
    </script>
</body>
</html>